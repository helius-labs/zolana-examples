# helius-wallet-kit

Embedded Solana wallets for Helius customers. One React provider with focused
hooks — your users get non-custodial embedded wallets, and you're billed
through your existing Helius plan.

```tsx
import { HeliusWalletProvider, useHeliusWallet } from 'helius-wallet-kit';

// Wrap your app
<HeliusWalletProvider config={{ apiKey: process.env.NEXT_PUBLIC_HELIUS_API_KEY! }}>
  {children}
</HeliusWalletProvider>

// Use in any component
const { address, login, signAndSendTransaction, connection } = useHeliusWallet();
```

## Subpath exports

Single npm package. Source is organized into subdirectories that map to subpath exports:

| Import | Purpose |
|---|---|
| `helius-wallet-kit` | Meta — re-exports `core` + `ui` for the default install |
| `helius-wallet-kit/core` | Provider, wallet and session hooks, Helius integrations |
| `helius-wallet-kit/ui/styles.css` | Wallet-modal stylesheet — pulls in the base modal styles and hides third-party branding. Import once in your root layout. |
| `helius-wallet-kit/next` | Next.js middleware — server-side proxies for the Helius API routes the client expects |

## Prerequisites

- Node.js 18+
- A Helius account on any paid plan ([dashboard.helius.dev](https://dashboard.helius.dev))

## Quick start

```bash
npm install helius-wallet-kit
```

Import the stylesheet in your root layout:

```tsx
// src/app/layout.tsx
import "helius-wallet-kit/ui/styles.css";
```

Wrap your app:

```tsx
// src/app/providers.tsx
'use client';
import { HeliusWalletProvider } from 'helius-wallet-kit';

export function Providers({ children }) {
  return (
    <HeliusWalletProvider
      config={{
        apiKey: process.env.NEXT_PUBLIC_HELIUS_API_KEY!,
        cluster: 'devnet',
      }}
    >
      {children}
    </HeliusWalletProvider>
  );
}
```

Done. `useHeliusWallet()` works in any client component under the provider — no server route required (see [Going proxy-less](#going-proxy-less-secure-rpc-url)).

## Composing attested wallet extensions

An attested extension can reuse the same login without mounting another wallet
provider:

```tsx
import { useHeliusWalletSession } from "helius-wallet-kit";

const session = useHeliusWalletSession();
const bootProof = await session.getBootProofForAppProof(appProof);
```

This is intentionally a narrow bridge: it exposes session state and Boot Proof
lookup, but no signing or export methods. Its pre-production
`authorizeTvcWallet` operation can install one P-256 enclave
credential plus five exact per-wallet TVC policies in the active embedded
wallet's child organization. Calling it again reconciles missing policies for
an existing wallet; the fifth policy permits only a default-ring SOL withdrawal
back to that wallet's own public address. A privacy or enclave package must
verify the returned proof using independently pinned trust inputs and keep its
own operation authorization policy. This lets such packages remain separate
today while sharing one user session, and leaves a clean seam if their UI is
later merged into this package.

**(Optional) Add the route handler** to keep your API key fully server-side, or to use transaction history and Sender-optimized landing:

```ts
// src/app/api/helius/[...path]/route.ts
import { createHeliusRouteHandler } from 'helius-wallet-kit/next';
export const { GET, POST } = createHeliusRouteHandler();
```

> **Note on your API key.** In this version the provider reads the key on the
> client (`NEXT_PUBLIC_HELIUS_API_KEY`), so it is visible in the browser. It's
> sent to Helius to bootstrap the wallet (origin-locked by the key's allowed
> domains) and to your route handler for RPC/transactions. Use a dedicated,
> domain-restricted key you can rotate. Fully server-side key handling (key
> never leaves your server) is on the roadmap.

## Going proxy-less (Secure RPC URL)

You can run the core wallet — login, sign, and send — with **no route handler**.
As of `0.2.0` the SDK fetches your project's key-less **Secure RPC URLs** and its
project id (for usage attribution) during bootstrap, so the minimal config is
just your API key:

```tsx
<HeliusWalletProvider
  config={{
    apiKey: process.env.NEXT_PUBLIC_HELIUS_API_KEY!,
    cluster: "mainnet-beta",
  }}
>
```

The wallet's Solana connection, priority-fee lookups, and `signAndSendTransaction`
then go **directly** to the secure URL — no route handler, and no API key on the
RPC path. (The bootstrap itself calls Helius with your API key, origin-locked by
the key's allowed domains.)

To pin the endpoints yourself (local/staging, or a self-hosted proxy), pass
`secureRpcUrl` per cluster — an explicit value overrides the auto-fetched one:

```tsx
secureRpcUrl: {
  "mainnet-beta": "https://<your>-fast-mainnet.helius-rpc.com",
  devnet: "https://<your>-fast-devnet.helius-rpc.com",
},
```

**Two things direct mode does not cover:**

- **Transaction history** (`getTransactions`) uses the Enhanced Transactions API,
  which has no secure-URL equivalent — it still needs the route handler.
- **Sender-optimized landing** — direct sends use standard RPC
  (`sendRawTransaction`), not Helius Sender's Jito routing. Mount the route
  handler if you want Sender.

## Architecture in one paragraph

`HeliusWalletProvider` fetches bootstrap config from a Helius-owned `/waas/config` endpoint on mount, then stands up a non-custodial wallet client under the hood. Developers don't see or depend on the backing wallet infrastructure — it's an internal implementation detail isolated behind a single adapter module, so it can be swapped or upgraded without changing the consumer API.

## License

MIT.
