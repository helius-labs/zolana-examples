# Changelog

## 1.1.0

- **Key-less mode (route-handler-backed)**: omit `apiKey` from
  `HeliusWalletProvider` and the SDK ships **no Helius API key in the browser** —
  the wallet bootstrap, wallet registration, and RPC/send all route through the
  same-origin Next.js route handler (`helius-wallet-kit/next`), which holds
  `HELIUS_API_KEY` server-side. Recommended for production.
  - `createHeliusRouteHandler()` now serves the bootstrap: its `waas/config`
    route injects the server key and forwards to dev-api, and the `waas/wallets`
    route registers wallets the same way (so the key-gated registry — which
    drives billing — stays trustworthy).
- **Keyed mode (quick start)**: set `apiKey` and the bootstrap is fetched
  directly with the key in the browser (domain-restrict it). Unchanged; good for
  prototyping.
- Signing and billing are unchanged in both modes.

## 1.0.0

First stable release.

- Embedded Solana wallets via one provider (`HeliusWalletProvider`) and one hook (`useHeliusWallet`).
- Sign-in with passkey, email, SMS, external wallet, or social (Google / Apple / Discord / X). Methods are configured per project in the Helius dashboard.
- Client-side signing via Turnkey: `signMessage`, `signTransaction`, `signAndSendTransaction`, wallet export, transaction history, and priority-fee helpers.
- Proxy-less by default — connects directly to key-less Secure RPC URLs resolved from your API key at bootstrap. Optional Next.js route handler (`helius-wallet-kit/next`) for fully server-side keys, transaction history, and Sender-optimized landing.
- Available on any paid Helius plan; billed through your existing credits (200 credits per signature).

The 1.0.0-rc.\* entries below record the changes made during the release-candidate cycle that ship in this release.

## 1.0.0-rc.6

- Fix email signups being reported as "SMS" in the dashboard's sign-in-method
  breakdown. Turnkey's `onAuthenticationSuccess` gives an opaque
  `verificationToken` for OTP (not the email/phone) and no OTP channel, so the
  old `identifier.includes("@")` check always failed. Classify OTP by the
  project's enabled methods instead (SMS only when it's the sole OTP method,
  otherwise email).

## 1.0.0-rc.5

- Reorder the sign-in modal to email OTP, external wallet, then passkey (SMS and
  social/OAuth last), via `methodOrder`.
- Remove the connected-wallet signing path added in rc.4. External wallet is a
  login method only: the operated wallet is always the embedded Helius wallet
  (so every signature routes through Turnkey and is metered), and the connected
  branch was never reached.

## 1.0.0-rc.4

- Fix external (connected) wallet transaction signing. Sends from a wallet the
  end user connected via their own extension (Phantom, Solflare, Backpack, …)
  now sign through that extension instead of the embedded-only Turnkey signer,
  which previously hung at "Signing…" with no prompt. Embedded (passkey/email)
  signing is unchanged.
- Register each end-user wallet with Helius on signup (address, sub-org, wallet
  id, and the sign-in method captured from Turnkey's `onAuthenticationSuccess`),
  so the dashboard can show wallet counts and the sign-in-method breakdown.
  Best-effort and idempotent — never blocks the app.

## 1.0.0-rc.3

- Set an OAuth redirect URI (defaults to the app origin; override via
  `config.oauthRedirectUri`) so social sign-in no longer throws "OAuth Redirect
  URI is not configured." The URI must be authorized on the OAuth client.
- Order the sign-in modal with primary methods first and social/OAuth last
  (`methodOrder`).

## 1.0.0-rc.2

- Apply the per-project sign-in methods configured in the Helius dashboard: the
  provider now reads `authMethods` from the bootstrap and uses them when no
  explicit `config.authMethods` override is passed (override → dashboard →
  Turnkey org defaults).
